package com.example.reddrip;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class Acceuil extends AppCompatActivity {
    //Hooks
    //TextView TVPseudo;
    TextView TVDateDeNaissance;
    TextView TVGroupeSanguin;
    Button btnPrf;
    Button btndonner;
    Button btnchercher;
    DatabaseReference reference;

    LinearLayout layoutList;
    Button deconnexion;

    private  static  final int REQUEST_CALL =1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceuil);
        btnPrf = findViewById(R.id.btnProfile);
        btndonner = findViewById(R.id.btndonner);
        deconnexion = findViewById(R.id.deconnexion);
        layoutList = findViewById(R.id.layout_list_accueil);
        reference = FirebaseDatabase.getInstance().getReference().child("Annonce");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                layoutList.removeAllViews();
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    Annonce annonceDon = snapshot1.getValue(Annonce.class);
                    //Toast.makeText(Acceuil.this, annonceDon.getEmail(), Toast.LENGTH_LONG).show();
                    //String nom = annonceDon.getDescription();
                    addView(annonceDon.getNom(),annonceDon.getSexe(),annonceDon.getGs(),annonceDon.getAge(),annonceDon.getEmail(),annonceDon.getDescription(),annonceDon.getNum_tel(),annonceDon.getAdresse(),annonceDon.getType().equals("Donnateur"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        Intent i = getIntent();
        String email = i.getStringExtra("email");
        String password = i.getStringExtra("password");
        String nom = i.getStringExtra("nom");
        String prenom = i.getStringExtra("prenom");
        String gs = i.getStringExtra("gs");
        String num = i.getStringExtra("num");
        String adresse = i.getStringExtra("adresse");
        //Toast.makeText(Acceuil.this, email, Toast.LENGTH_LONG).show();
        //l'adresse n'est pas passée
        Toast.makeText(Acceuil.this, adresse, Toast.LENGTH_LONG).show();

        btnPrf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Acceuil.this, UserProfile.class);
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                intent.putExtra("nom", nom);
                intent.putExtra("prenom", prenom);
                intent.putExtra("gs", gs);
                intent.putExtra("num", num);
                intent.putExtra("adresse", adresse);
                startActivity(intent);
            }
        });

        btndonner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Acceuil.this, Recherche.class);
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                intent.putExtra("nom", nom);
                intent.putExtra("prenom", prenom);
                intent.putExtra("gs", gs);
                intent.putExtra("num", num);
                intent.putExtra("adresse", adresse);
                startActivity(intent);
            }
        });

        deconnexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences;
                preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = preferences.edit();
                editor.clear().commit();
                Intent intent = new Intent(Acceuil.this, Login.class);
                startActivity(intent);
            }
        });


    }

    public void addView(String nom,String sexe,String gs,int age,String email,String description,String numero,String adresse,boolean don){
        //Toast.makeText(Acceuil.this, "c'est la bonne fonction", Toast.LENGTH_LONG).show();
        View cricketerView = getLayoutInflater().inflate(R.layout.activity_user_profile3,null,false);


        //TextView date_card = (TextView)cricketerView.findViewById(R.id.date_card);
        //ImageView type_card = (ImageView)cricketerView.findViewById(R.id.type_card);
        //Button button2 = (Button)cricketerView.findViewById(R.id.remove_card);


        TextView viewNom = cricketerView.findViewById(R.id.textView8);
        TextView viewSexe = cricketerView.findViewById(R.id.textView9);
        TextView viewGs = cricketerView.findViewById(R.id.textView10);
        TextView viewAge = cricketerView.findViewById(R.id.textView);
        TextView viewEmail = cricketerView.findViewById(R.id.date_card);
        TextView viewDescription = cricketerView.findViewById(R.id.descr);

        ImageView imageView = cricketerView.findViewById(R.id.type_card);
        Button button2 = cricketerView.findViewById(R.id.remove_card);
        Button appeler = cricketerView.findViewById(R.id.appel);




        viewNom.setText(nom);
        viewSexe.setText(sexe);
        viewGs.setText(gs);
        viewAge.setText(Integer.toString(age));
        viewEmail.setText(email);
        viewDescription.setText(description);
        if(don) {
            imageView.setImageResource(R.drawable.plus);
        }else{
            imageView.setImageResource(R.drawable.remove);
        }
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Acceuil.this, "bouton", Toast.LENGTH_LONG).show();
                Uri gmmIntentUri = Uri.parse("geo:0,0?q="+adresse);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        appeler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Acceuil.this, "imageView.toString()", Toast.LENGTH_LONG).show();
                makePhoneCall(numero);
            }
        });

        layoutList.addView(cricketerView);
    }


    public void addViewRecherche(String nom,String sexe,String gs,int age,String email,String description,String adresse,boolean don){
        //Toast.makeText(Acceuil.this, "c'est la bonne fonction", Toast.LENGTH_LONG).show();
        View cricketerView = getLayoutInflater().inflate(R.layout.activity_user_profile3,null,false);


        //TextView date_card = (TextView)cricketerView.findViewById(R.id.date_card);
        //ImageView type_card = (ImageView)cricketerView.findViewById(R.id.type_card);
        //Button button2 = (Button)cricketerView.findViewById(R.id.remove_card);


        TextView viewNom = cricketerView.findViewById(R.id.textView8);
        TextView viewSexe = cricketerView.findViewById(R.id.textView9);
        TextView viewGs = cricketerView.findViewById(R.id.textView10);
        TextView viewAge = cricketerView.findViewById(R.id.textView);
        TextView viewEmail = cricketerView.findViewById(R.id.date_card);
        TextView viewDescription = cricketerView.findViewById(R.id.descr);

        ImageView imageView = cricketerView.findViewById(R.id.type_card);
        Button button2 = cricketerView.findViewById(R.id.remove_card);
        Button appeler = cricketerView.findViewById(R.id.appel);




        viewNom.setText(nom);
        viewSexe.setText(sexe);
        viewGs.setText(gs);
        viewAge.setText(Integer.toString(age));
        viewEmail.setText(email);
        viewDescription.setText(description);
        if(don) {
            imageView.setImageResource(R.drawable.plus);
        }else{
            imageView.setImageResource(R.drawable.remove);
        }
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Acceuil.this, "bouton", Toast.LENGTH_LONG).show();
                Uri gmmIntentUri = Uri.parse("geo:0,0?q="+adresse);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        appeler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Acceuil.this, "imageView.toString()", Toast.LENGTH_LONG).show();
                makePhoneCall("123456");
            }
        });

        layoutList.addView(cricketerView);
    }



    private void makePhoneCall(String number){
        if (ContextCompat.checkSelfPermission(Acceuil.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Acceuil.this , new String[] {Manifest.permission.CALL_PHONE}, REQUEST_CALL);
        }else
        {
            String dial = "tel:"+number;
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(dial)));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                makePhoneCall("123456");
            }
            else
            {
                Toast.makeText(this,"Permission DENIED",Toast.LENGTH_SHORT).show();
            }
        }
    }
}