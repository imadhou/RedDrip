package com.example.reddrip;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.Map;

public class Login extends AppCompatActivity {
    //Elements layout
    Button btnConnexion;
    EditText etEmail, etPassword;
    TextView tvRedirect;

    //Shared preferences
    SharedPreferences preferences;


    //Variables intent
    String nomFromDatabase;
    String prenomFromDatabase;
    String emailFromDataBase;
    String passwordFromDatabase;
    String numFromDatabase;
    String adresseFromDatabase;
    String gsFromDataBase;

    //Variables layout
    String userEnteredEmail;
    String userEnteredPassword;
    DatabaseReference reference;
    Query checkUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        etEmail = findViewById(R.id.etLoginEmail);
        tvRedirect = findViewById(R.id.tvLoginRedirectRegister);
        etPassword = findViewById(R.id.etLoginPassword);
        btnConnexion = findViewById(R.id.btnConnexion);

        btnConnexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userEnteredEmail = etEmail.getText().toString().trim();
                userEnteredPassword = etPassword.getText().toString().trim();
                reference = FirebaseDatabase.getInstance().getReference("User");
                checkUser = reference.orderByChild("email").equalTo(userEnteredEmail);
                String registredEmail = preferences.getString("email", "");
                String registredPassword = preferences.getString("password", "");

                checkUser.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        if (snapshot.exists()) {
                            etEmail.setError(null);
                            Map<String, String> map = (Map<String, String>) snapshot.getValue();
                            String passwordFromDataBase = map.get("password");
                            if (passwordFromDataBase.equals(userEnteredPassword)) {
                                String nomFromdatabase = map.get("nom");
                                String prenomnomFromdatabase = map.get("prenom");
                                emailFromDataBase = map.get("email");
                                passwordFromDataBase = map.get("password");
                                gsFromDataBase = map.get("gs");
                                String numFromdatabase = map.get("numTel");
                                String adresseFromDatabase = map.get("adresse");
                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putString("nom", nomFromdatabase);
                                editor.putString("prenom", prenomFromDatabase);
                                editor.putString("email", emailFromDataBase);
                                editor.putString("password", passwordFromDataBase);
                                editor.putString("num", numFromDatabase);
                                editor.putString("adresse", adresseFromDatabase);
                                editor.putString("gs", gsFromDataBase);
                                editor.commit();

                                Intent redirectLoginAcceuil = new Intent(Login.this, Acceuil.class);
                                redirectLoginAcceuil.putExtra("email", emailFromDataBase);
                                redirectLoginAcceuil.putExtra("password", passwordFromDataBase);
                                redirectLoginAcceuil.putExtra("nom", nomFromdatabase);
                                redirectLoginAcceuil.putExtra("prenom", prenomFromDatabase);
                                redirectLoginAcceuil.putExtra("gs", gsFromDataBase);
                                redirectLoginAcceuil.putExtra("num", numFromdatabase);
                                redirectLoginAcceuil.putExtra("adresse", adresseFromDatabase);
                                startActivity(redirectLoginAcceuil);
                            } else {
                                etPassword.setError("Wrong Password");
                                etPassword.requestFocus();
                            }

                        } else {
                            etEmail.setError("Utilisateur inexistant");
                            etEmail.requestFocus();
                        }
                    }


                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        System.out.println("onChildChanged");

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                        System.out.println("onChildRemoved");

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        System.out.println("onChildMoved");
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        System.out.println("onCancelled");
                    }
                });

            }
        });

        tvRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent redirectLoginRegister = new Intent(Login.this, Register.class);
                startActivity(redirectLoginRegister);

            }
        });
    }


}