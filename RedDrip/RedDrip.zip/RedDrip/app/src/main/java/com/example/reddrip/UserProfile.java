package com.example.reddrip;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UserProfile extends AppCompatActivity {
    //Hooks
    /*EditText etPseudo = findViewById(R.id.etPseudoAcceuil);
    EditText etDateDeNaissance = findViewById(R.id.etDateNaissance);
    EditText etGroupeSanguin = findViewById(R.id.etGroupeSanguin);*/

    LinearLayout layoutList;
    //LinearLayout layoutList2;
    Button buttonAdd;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile2);

        layoutList = findViewById(R.id.layout_list);
        //buttonAdd = findViewById(R.id.button_add);





        /*layoutList2 = findViewById(R.id.layout_list2);
        View View2 = getLayoutInflater().inflate(R.layout.activity_cards,null,false);

        //EditText editText = (EditText)cricketerView.findViewById(R.id.edit_cricketer_name);

        TextView date_card2 = (TextView)View2.findViewById(R.id.date_card);
        ImageView type_card2 = (ImageView)View2.findViewById(R.id.type_card);
        Button button22 = (Button)View2.findViewById(R.id.remove_card);

        date_card2.setText("test");
        type_card2.setImageResource(R.drawable.plus);

        layoutList2.addView(View2);*/

        //addView("1",true,"13");
        //addView("2",true);
        //addView("3",true);
        //addView("4",true);
        //addView("5",true);
        //addView("6",true);


        Intent i = getIntent();
        String email = i.getStringExtra("email");
        String password = i.getStringExtra("password");
        String nom = i.getStringExtra("nom");
        String prenom = i.getStringExtra("prenom");
        String gs = i.getStringExtra("gs");
        String num = i.getStringExtra("num");
        String adresse = i.getStringExtra("adresse");
        Toast.makeText(UserProfile.this, email, Toast.LENGTH_LONG).show();


        reference = FirebaseDatabase.getInstance().getReference().child("Annonce");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                layoutList.removeAllViews();
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    Annonce annonceDon = snapshot1.getValue(Annonce.class);
                    //String key = snapshot1.getKey();
                    //Toast.makeText(UserProfile.this, snapshot1.getKey(), Toast.LENGTH_LONG).show();
                    // ici remplacer par les données obtenues d'un intent
                    if(annonceDon.getEmail().equals(email)) {
                    addView(annonceDon.getDescription(), annonceDon.getType().equals("Donnateur"),snapshot1.getKey());
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        /*reference = FirebaseDatabase.getInstance().getReference().child("AnnonceRecherche");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                layoutList.removeAllViews();
                for (DataSnapshot snapshot2 : snapshot.getChildren()){
                    AnnonceRecherche annonceRecherche = snapshot2.getValue(AnnonceRecherche.class);

                    // ici remplacer par les données obtenues d'un intent
                    //if(annonceRecherche.getEmail().equals("q")) {
                    addView(annonceRecherche.getDescription(), false,snapshot2.getKey());
                    //}
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });*/



        /*buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //addView("31/12/2020",true);
            }
        });*/


    }

    public void removeView(View view,String key){
        Toast.makeText(UserProfile.this, "remove "+key, Toast.LENGTH_LONG).show();
        DatabaseReference dbremove;
            dbremove = FirebaseDatabase.getInstance().getReference("Annonce").child(key);
        dbremove.removeValue();
        layoutList.removeView(view);
    }

    public void addView(String date,boolean don,String key){
        //Toast.makeText(UserProfile.this, key, Toast.LENGTH_LONG).show();
        View cricketerView = getLayoutInflater().inflate(R.layout.activity_cards,null,false);

        //EditText editText = (EditText)cricketerView.findViewById(R.id.edit_cricketer_name);

        TextView date_card = cricketerView.findViewById(R.id.date_card);
        ImageView type_card = cricketerView.findViewById(R.id.type_card);
        Button button2 = cricketerView.findViewById(R.id.remove_card);


        date_card.setText(date);
        if(don) {
            type_card.setImageResource(R.drawable.plus);
        }else{
            type_card.setImageResource(R.drawable.remove);
        }
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeView(cricketerView,key);

            }
        });

        /*AppCompatSpinner spinnerTeam = (AppCompatSpinner)cricketerView.findViewById(R.id.spinner_team);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,teamList);
        spinnerTeam.setAdapter(arrayAdapter);*/


        layoutList.addView(cricketerView);
    }





}