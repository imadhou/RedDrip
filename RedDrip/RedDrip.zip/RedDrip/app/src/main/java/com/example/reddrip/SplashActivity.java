package com.example.reddrip;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.Map;

public class SplashActivity extends AppCompatActivity {
    private final static int SPLASH_SCREEN_TIMEOUT = 3000;
    SharedPreferences preferences = null;
    DatabaseReference reference;
    Query checkUser;
    String savedEmail;
    String savedPassword;
    Query check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        reference = FirebaseDatabase.getInstance().getReference("User");
        checkUser = reference.orderByChild("email").equalTo(savedEmail);
        savedEmail = preferences.getString("email", "");
        savedPassword = preferences.getString("password", "");
        check = reference.orderByChild("email").equalTo(savedEmail);


        Intent intent = new Intent(this, AnnoncesProches.class);
        String sang = preferences.getString("gs","");
        intent.putExtra("sang",sang);
        startService(intent);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (savedEmail.trim().equals("") || savedPassword.trim().equals("")) {
                    System.out.println("Breakpoint");
                    Intent firstTime = new Intent(SplashActivity.this, Login.class);
                    startActivity(firstTime);
                    finish();
                }

                check.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        if (snapshot.exists()) {
                            Map<String, String> map = (Map<String, String>) snapshot.getValue();
                            String passwordFromDataBase = map.get("password");
                            if (passwordFromDataBase.equals(savedPassword)) {
                                String nomFromdatabase = map.get("nom");
                                String prenomFromDatabase = map.get("prenom");
                                String emailFromDataBase = map.get("email");
                                String gsFromDataBase = map.get("gs");
                                String numFromDatabase = map.get("num");
                                String adresseFromDatabase = map.get("adresse");

                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putString("nom", nomFromdatabase);
                                editor.putString("prenom", prenomFromDatabase);
                                editor.putString("email", emailFromDataBase);
                                editor.putString("password", passwordFromDataBase);
                                editor.putString("num", numFromDatabase);
                                editor.putString("adresse", adresseFromDatabase);
                                editor.putString("gs", gsFromDataBase);
                                editor.commit();

                                Intent redirectAcceuil = new Intent(SplashActivity.this, Acceuil.class);
                                redirectAcceuil.putExtra("email", emailFromDataBase);
                                redirectAcceuil.putExtra("password", passwordFromDataBase);
                                redirectAcceuil.putExtra("nom", nomFromdatabase);
                                redirectAcceuil.putExtra("prenom", prenomFromDatabase);
                                redirectAcceuil.putExtra("gs", gsFromDataBase);
                                redirectAcceuil.putExtra("num", numFromDatabase);
                                redirectAcceuil.putExtra("adresse", adresseFromDatabase);
                                startActivity(redirectAcceuil);
                                finish();
                            } else {
                                Intent redirectRegister = new Intent(SplashActivity.this, Login.class);
                                startActivity(redirectRegister);
                                finish();
                            }

                        }


                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        }, 3000);

    }
}


